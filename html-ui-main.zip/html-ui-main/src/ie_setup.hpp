#pragma once

namespace momo
{
	void setup_internet_explorer();
}
